#!/bin/bash
# Double-click this if the app icon is blocked by macOS.
cd "$(dirname "$0")"
xattr -cr "." 2>/dev/null || true
APP="Matter Tracker.app"
if [ -d "$APP" ]; then
  xattr -cr "$APP" 2>/dev/null || true
  open "$APP"
  exit 0
fi
DIR="$(pwd)/Matter Tracker.app/Contents/Resources"
PY="$(command -v python3 || echo /usr/bin/python3)"
"$PY" "$DIR/app.py" --serve >/dev/null 2>&1 &
for i in 1 2 3 4 5 6 7 8 9 10; do
  curl -s -o /dev/null --max-time 1 "http://127.0.0.1:8765/api/health" && break
  sleep 0.3
done
open "http://127.0.0.1:8765/"
